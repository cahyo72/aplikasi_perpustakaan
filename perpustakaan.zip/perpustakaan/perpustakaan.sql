-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 17 Jun 2016 pada 08.33
-- Versi Server: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_perpustakaan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `anggota`
--

CREATE TABLE IF NOT EXISTS `anggota` (
  `id` varchar(10) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `jk` varchar(2) DEFAULT NULL,
  `ttl` date DEFAULT NULL,
  `kategori` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `anggota`
--

INSERT INTO `anggota` (`id`, `nama`, `jk`, `ttl`, `kategori`) VALUES
('A0002', 'Anggota 2', 'P', '2000-05-10', 'Umum'),
('A0003', 'Anggota 3', 'P', '2016-06-01', 'Mahasiswa'),
('A0004', 'Anggota 4', 'L', '2000-03-11', 'Umum'),
('A0005', 'Anggota 5', 'L', '2000-02-02', 'Dosen');

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE IF NOT EXISTS `buku` (
  `kode_buku` varchar(5) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `pengarang` varchar(50) DEFAULT NULL,
  `stok` int(5) NOT NULL,
  `k_buku` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`kode_buku`, `judul`, `pengarang`, `stok`, `k_buku`) VALUES
('34578', 'Warkop MIllenium', 'Dono Kasino Indro', 86, ''),
('B0008', 'Buku 8', 'Author 8', 77, 'Umum'),
('RCTI0', 'CHSI', 'Asma nadia', 75, 'Dewasa'),
('rt567', 'saklek', 'sarimin', 22, 'Dongeng'),
('S3000', 'Resident evil 5', 'Umbrella', 45, 'Horor');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengembalian`
--

CREATE TABLE IF NOT EXISTS `pengembalian` (
  `id_transaksi` varchar(12) DEFAULT NULL,
  `tgl_pengembalian` date DEFAULT NULL,
  `denda` varchar(2) DEFAULT NULL,
  `nominal` double DEFAULT NULL,
  `id_petugas` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `pengembalian`
--

INSERT INTO `pengembalian` (`id_transaksi`, `tgl_pengembalian`, `denda`, `nominal`, `id_petugas`) VALUES
('20160616001', '2016-06-16', 'N', 0, NULL),
('20160616001', '2016-06-16', 'N', 0, NULL),
('20160616003', '2016-06-16', 'N', 0, NULL),
('20160616003', '2016-06-16', 'N', 0, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `petugas`
--

CREATE TABLE IF NOT EXISTS `petugas` (
`id_petugas` int(11) NOT NULL,
  `user` varchar(45) DEFAULT NULL,
  `password` text
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `user`, `password`) VALUES
(3, 'admin', '0192023a7bbd73250516f069df18b500');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tmp`
--

CREATE TABLE IF NOT EXISTS `tmp` (
  `kode_buku` varchar(5) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `pengarang` varchar(50) NOT NULL,
  `stok` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE IF NOT EXISTS `transaksi` (
  `id_transaksi` varchar(12) NOT NULL,
  `id` varchar(10) NOT NULL,
  `kode_buku` varchar(5) NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `tanggal_kembali` date NOT NULL,
  `status` varchar(5) NOT NULL,
  `id_petugas` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id`, `kode_buku`, `tanggal_pinjam`, `tanggal_kembali`, `status`, `id_petugas`) VALUES
('20160616001', 'A0001', '23456', '2016-06-16', '2016-06-18', 'Y', ''),
('20160616001', 'A0001', '34578', '2016-06-16', '2016-06-18', 'Y', ''),
('20160616001', 'A0001', 'rt567', '2016-06-16', '2016-06-18', 'Y', ''),
('20160616002', 'A0002', 'B0008', '2016-06-16', '2016-06-18', 'N', ''),
('20160616003', 'A0009', '34578', '2016-06-16', '2016-06-18', 'Y', ''),
('20160616003', 'A0009', '23456', '2016-06-16', '2016-06-18', 'Y', ''),
('20160616004', 'A0009', 'B0008', '2016-06-16', '2016-06-18', 'N', ''),
('20160616004', 'A0009', '23456', '2016-06-16', '2016-06-18', 'N', ''),
('20160616005', 'A0004', '34578', '2016-06-16', '2016-06-18', 'N', ''),
('20160616005', 'A0004', 'RCTI0', '2016-06-16', '2016-06-18', 'N', ''),
('20160616006', 'A0002', 'RCTI0', '2016-06-16', '2016-06-18', 'N', ''),
('20160616006', 'A0002', '34578', '2016-06-16', '2016-06-18', 'N', ''),
('20160617001', 'A0003', 'rt567', '2016-06-17', '2016-06-19', 'N', ''),
('20160617002', 'A0003', '34578', '2016-06-17', '2016-06-19', 'N', ''),
('20160617002', 'A0003', 'B0008', '2016-06-17', '2016-06-19', 'N', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
 ADD PRIMARY KEY (`kode_buku`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
 ADD PRIMARY KEY (`id_petugas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
