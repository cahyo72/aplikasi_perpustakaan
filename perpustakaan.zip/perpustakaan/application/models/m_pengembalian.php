<?php
class M_Pengembalian extends CI_Model{
    
    function cariTransaksi($no){
        $query=$this->db->query("select a.*,b.nama from transaksi a,
                                anggota b
                                where a.id_transaksi='$no' and a.id_transaksi
                                not in(select id_transaksi from pengembalian)
                                and a.id=b.id");
        return $query;
    }
    
    function tampilBuku($no){
        $query=$this->db->query("select a.*,b.judul,b.pengarang,b.stok
                                from transaksi a,buku b
                                where a.id_transaksi='$no' and
                                a.id_transaksi not in(select id_transaksi from pengembalian)
                                and a.kode_buku=b.kode_buku");
        return $query;
    }
    
    function simpan($info){
        $this->db->insert("pengembalian",$info);
    }
    
    function update($no,$update){
        $this->db->where("id_transaksi",$no);
        $this->db->update("transaksi",$update);
    }
	
	function update_stok($kode,$stok){
		$this->db->set("stok",$stok);
		$this->db->where("kode_buku",$kode);
		$this->db->update("buku");
    }
    
    function cari_by_id($id){
        $query=$this->db->query("select * from transaksi where id_transaksi
                                not in(select id_transaksi from pengembalian)
                                and id like '%$id%' group by id_transaksi");
        return $query;
    }
}