<div class="panel panel-default">
    <div class="panel-heading">
        Administrator
    </div>
    <div class="panel-body">
        <div class="container">
            
                  <a href="<?php echo site_url('anggota');?>" class="btn btn-primary">Anggota</a>
                
                  <a href="<?php echo site_url('buku');?>" class="btn btn-primary">Buku</a>
                
                  <a href="<?php echo site_url('peminjaman');?>" class="btn btn-primary">Peminjaman</a>
                
                  <a href="<?php echo site_url('pengembalian');?>" class="btn btn-primary">Pengembalian</a>
				  
				  <a href="<?php echo site_url('laporan/peminjaman');?>" class="btn btn-primary">Rekap Peminjaman</a>
                
                  <a href="<?php echo site_url('dashboard/logout');?>" class="btn btn-primary">Logout</a>
            
        </div>
    </div>
</div>