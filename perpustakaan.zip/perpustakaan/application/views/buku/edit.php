<script>
$(function(){
	$("#k_baru").attr("disabled",true);
	document.getElementById('k_baru').style.visibility = "hidden";
	$("#k_buku").attr("disabled",false);
	$("#k_buku").click(function(){
		var k_buku=$("#k_buku").val();
		
		if (k_buku=="N") {
			//code
			$("#k_baru").attr("disabled",false);
			$("#k_baru").focus();
			document.getElementById('k_baru').style.visibility = "visible";
		}else{
			$("#k_baru").attr("disabled",true);
			document.getElementById('k_baru').style.visibility = "hidden";
		}
	})
	
	
})
</script>
<div class="panel panel-default">
<div class="panel-heading">
<div class="nav navbar-nav navbar-Left">
</div>

<form class="form-horizontal" action="" method="post" enctype="multipart/form-data" />
    <?php echo validation_errors(); echo $message;?>
   
   <div class="form-group">
        <label class="col-lg-2 control-label">Kode Buku</label>
        <div class="col-lg-5">
            <input type="text" name="kode" class="form-control" value="<?php echo $buku['kode_buku'];?>" readonly="readonly">
        </div>
    </div>
    
    <div class="form-group">
        <label class="col-lg-2 control-label">Judul Buku</label>
        <div class="col-lg-5">
            <input type="text" name="judul" class="form-control" value="<?php echo $buku['judul'];?>">
        </div>
    </div>
    
    <div class="form-group">
        <label class="col-lg-2 control-label">Pengarang</label>
        <div class="col-lg-5">
            <input type="text" name="pengarang" class="form-control" value="<?php echo $buku['pengarang'];?>">
        </div>
    </div>
	
	<div class="form-group">
        <label class="col-lg-2 control-label">Stok</label>
        <div class="col-lg-5">
            <input type="text" name="stok" class="form-control" value="<?php echo $buku['stok'];?>">
        </div>
    </div>
	
	<div class="form-group">
	<label class="col-lg-2 control-label">Kategori Buku</label>
        <div class="col-lg-5">
			<select name="k_buku" id="k_buku" class="form-control">
				<option></option>
				<?php foreach($jenis as $jenis):?>
				<option value="<?php echo $jenis->k_buku;?>"><?php echo $jenis->k_buku;?></option>
				<?php endforeach;?>
				<option value="N">Kategori baru</option>
			</select>
        </div>
	</div>
	
	<div class="form-group">
	<label class="col-lg-2 control-label"></label>
        <div class="col-lg-5">
            <input type="text" name="k_baru" id="k_baru" placeholder="Kategori baru" class="form-control">
        </div>
    </div>
    
    <div class="">
        <button class="btn btn-primary">Simpan</button>
        <a href="<?php echo site_url('buku');?>" class="btn btn-default">Kembali</a>
    </div>
</form>