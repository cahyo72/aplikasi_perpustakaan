<script>
    $(function(){
        $("#tampilkan").click(function(){
            var tanggal1=$("#tanggal1").val();
            var tanggal2=$("#tanggal2").val();
            
            $.ajax({
                url:"<?php echo site_url('laporan/cari_pinjaman');?>",
                type:"POST",
                data:"tanggal1="+tanggal1+"&tanggal2="+tanggal2,
                cache:false,
                success:function(html){
                    $("#tampil").html(html);
                }
            })
        })
    })
</script>

<div class="panel panel-default">
<div class="panel-heading">
<div class="nav navbar-nav navbar-Left">
</div>

<hr>

<div>
    <div>
        <label class="col-lg-3">Tanggal Awal</label>
        <div class="col-lg-3">
            <input type="date" id="tanggal1" class="form-control">
        </div>
    </div>
    
    <div>
        <label class="col-lg-3">Tanggal Selesai</label>
        <div class="col-lg-3">
            <input type="date" id="tanggal2" class="form-control">
        </div>
    </div>
	
	<div>
            <button id="tampilkan" class="btn btn-primary"><i class="glyphicon glyphicon-search"></i> Tampilkan</button>
			<a href="<?php echo site_url('dashboard');?>" class="btn btn-default">Kembali</a>
    </div>
</div>
</div>
</div>




<div id="tampil"></div>