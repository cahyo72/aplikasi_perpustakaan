<div class="panel panel-default">
<div class="panel-heading">
<div class="nav navbar-nav navbar-right">
</div>

<hr>
<?php echo $message;?>
<Table class="table">
    <thead>
        <tr>
            <td>No.</td>
            <td>ID Anggota</td>
            <td>Nama</td>
            <td>JK</td>
            <td>Tanggal Lahir</td>
            <td>Kategori Anggota</td>
            <td colspan="5"></td>
        </tr>
    </thead>
    <?php $no=0; foreach($anggota as $row ): $no++;?>
    <tr>
        <td><?php echo $no;?></td>
        <td><?php echo $row->id;?></td>
        <td><?php echo $row->nama;?></td>
        <td><?php echo $row->jk;?></td>
        <td><?php echo $row->ttl;?></td>
        <td><?php echo $row->kategori;?></td>
        <td><a href="<?php echo site_url('anggota/edit/'.$row->id);?>"><i class="btn btn-primary">Edit Data</i></a></td>
        <td><a href="#" class="hapus" kode="<?php echo $row->id;?>"><i class="btn btn-primary">Hapus Data</i></a></td>
    </tr>
    <?php endforeach;?>
</Table>
<?php echo $pagination;?>
<a href="<?php echo site_url('anggota/tambah');?>" class="btn btn-primary">Tambah</a>
<a href="<?php echo site_url('dashboard');?>" class="btn btn-default">Kembali</a>

<script>
    $(function(){
        $(".hapus").click(function(){
            var kode=$(this).attr("kode");
            
            $("#idhapus").val(kode);
            $("#myModal").modal("show");
        });
        
        $("#konfirmasi").click(function(){
            var kode=$("#idhapus").val();
            
            $.ajax({
                url:"<?php echo site_url('anggota/hapus');?>",
                type:"POST",
                data:"kode="+kode,
                cache:false,
                success:function(html){
                    location.href="<?php echo site_url('anggota/index/delete_success');?>";
                }
            });
        });
    });
</script>