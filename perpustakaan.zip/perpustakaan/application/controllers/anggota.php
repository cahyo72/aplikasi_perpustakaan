<?php
class Anggota extends CI_Controller{
    private $limit=20;
    
    function __construct(){
        parent::__construct();
        $this->load->library(array('template','pagination','form_validation','upload'));
        $this->load->model('m_anggota');
        
        if(!$this->session->userdata('username')){
            redirect('web');
        }
    }
    
    function index($offset=0,$order_column='id',$order_type='asc'){
        if(empty($offset)) $offset=0;
        if(empty($order_column)) $order_column='id';
        if(empty($order_type)) $order_type='asc';
        
        //load data
        $data['anggota']=$this->m_anggota->semua($this->limit,$offset,$order_column,$order_type)->result();
        $data['title']="Data Anggota";
        
        $config['base_url']=site_url('anggota/index/');
        $config['total_rows']=$this->m_anggota->jumlah();
        $config['per_page']=$this->limit;
        $config['uri_segment']=3;
        $this->pagination->initialize($config);
        $data['pagination']=$this->pagination->create_links();
        
        
        if($this->uri->segment(3)=="delete_success")
            $data['message']="<div class='alert alert-success'>Data berhasil dihapus</div>";
        else if($this->uri->segment(3)=="add_success")
            $data['message']="<div class='alert alert-success'>Data Berhasil disimpan</div>";
        else
            $data['message']='';
            $this->template->display('anggota/index',$data);
    }
    
    
    function edit($id){
        $data['title']="Edit Data Anggota";
        $this->_set_rules();
        if($this->form_validation->run()==true){
            $ids=$this->input->post('id');
            
            $info=array(
                'nama'=>$this->input->post('nama'),
                'ttl'=>$this->input->post('ttl'),
                'jk'=>$this->input->post('jk'),
				'kategori'=>$this->input->post('kategori')
            );
            //update data angggota
            $this->m_anggota->update($ids,$info);
            
            //tampilkan pesan
            $data['message']="<div class='alert alert-success'>Data Berhasil diupdate</div>";
            
            //tampilkan data anggota 
            $data['anggota']=$this->m_anggota->cek($id)->row_array();
            $this->template->display('anggota/edit',$data);
        }else{
            $data['anggota']=$this->m_anggota->cek($id)->row_array();
            $data['message']="";
            $this->template->display('anggota/edit',$data);
        }
    }
    
    
    function tambah(){
        $data['title']="Tambah Data Anggota";
        $this->_set_rules();
        if($this->form_validation->run()==true){
            $id=$this->input->post('id');
            $cek=$this->m_anggota->cek($id);
            if($cek->num_rows()>0){
                $data['message']="<div class='alert alert-warning'>ID sudah digunakan</div>";
                $this->template->display('anggota/tambah',$data);
            }else{
                $info=array(
                    'id'=>$this->input->post('id'),
                    'nama'=>$this->input->post('nama'),
                    'jk'=>$this->input->post('jk'),
                    'ttl'=>$this->input->post('ttl'),
                    'kategori'=>$this->input->post('kategori')
                );
                $this->m_anggota->simpan($info);
                redirect('anggota/index/add_success');
            }
        }else{
            $data['message']="";
            $this->template->display('anggota/tambah',$data);
        }
    }
    
    
    function hapus(){
        $kode=$this->input->post('kode');
        $detail=$this->m_anggota->cek($kode)->result();
	
	foreach($detail as $det):
	endforeach;
        $this->m_anggota->hapus($kode);
    }
    
    
    function _set_rules(){
        $this->form_validation->set_rules('id','ID','required|max_length[10]');
        $this->form_validation->set_rules('nama','Nama','required|max_length[50]');
        $this->form_validation->set_rules('jk','Jenis Kelamin','required|max_length[2]');
        $this->form_validation->set_rules('ttl','Tanggal Lahir','required');
        $this->form_validation->set_rules('kategori','Kategori','required|max_length[10]');
        $this->form_validation->set_error_delimiters("<div class='alert alert-danger'>","</div>");
    }
}